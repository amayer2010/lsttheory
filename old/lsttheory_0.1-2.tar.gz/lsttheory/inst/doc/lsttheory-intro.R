### R code from vignette source 'lsttheory-intro.Rnw'

###################################################
### code chunk number 1: wininstall1 (eval = FALSE)
###################################################
## install.packages("lavaan")  ## for lsttheory
## install.packages("shiny")  ## for user Interface
## install.packages("semPlot")  ## for plots


###################################################
### code chunk number 2: wininstall2 (eval = FALSE)
###################################################
## install.packages("D:/workspace/lsttheory_0.1-1.zip")


###################################################
### code chunk number 3: loading
###################################################
library("lsttheory")


###################################################
### code chunk number 4: datamultistate
###################################################
data(multistate)
head(round(multistate,2))


###################################################
### code chunk number 5: multistate01
###################################################
m1 <- lsttheory(neta=2, data=multistate)
print(m1)


###################################################
### code chunk number 6: multistate01_lavaansyntax
###################################################
cat(m1@lavaansyntax)


###################################################
### code chunk number 7: multistate01_lavaanout
###################################################
summary(m1@lavaanres)


###################################################
### code chunk number 8: multistate02
###################################################
m1 <- lsttheory(neta=2, data=multistate, 
                equiv.assumption=list(tau="ess", theta="equi"))
coef(m1@lavaanres, type="user")


###################################################
### code chunk number 9: multistate03
###################################################
m1 <- lsttheory(neta=2, data=multistate, 
                equiv.assumption=list(tau="equi", theta="equi"))
coef(m1@lavaanres, type="user")


###################################################
### code chunk number 10: multistate04
###################################################
m1 <- lsttheory(neta=2, data=multistate, 
                scale.invariance=list(lait0=TRUE, lait1=TRUE, lat0=TRUE, lat1=TRUE))
coef(m1@lavaanres, type="user")


###################################################
### code chunk number 11: multistate05 (eval = FALSE)
###################################################
## m1 <- lsttheory(neta=2, data=multistate, equiv.assumption=list(tau="ess", theta="equi"), scale.invariance=list(lait0=TRUE, lait1=TRUE, lat0=TRUE, lat1=TRUE))


###################################################
### code chunk number 12: multistatesingletrait01
###################################################
m1 <- lsttheory(neta=3, ntheta=1, data=multistate02)
print(m1)


###################################################
### code chunk number 13: multistatesingletrait02
###################################################
coef(m1@lavaanres, type="user")


###################################################
### code chunk number 14: multistatesingletrait03
###################################################
m1 <- lsttheory(neta=3, ntheta=1, data=multistate02, 
                equiv.assumption=list(tau="ess", theta="equi"), 
                scale.invariance=list(lait0=TRUE, lait1=TRUE, lat0=TRUE, lat1=TRUE))
coef(m1@lavaanres, type="user")


###################################################
### code chunk number 15: datamultitraitmultistate
###################################################
data(multitraitmultistate)
head(round(multitraitmultistate,2))


###################################################
### code chunk number 16: multistatedoubletrait01
###################################################
m1 <- lsttheory(neta=4, ntheta=2, data=multitraitmultistate)
coef(m1@lavaanres, type="user")


###################################################
### code chunk number 17: semplot01 (eval = FALSE)
###################################################
## library(semPlot)
## semPaths(m1@lavaanres, style="lisrel", intercepts=F, 
##          layout="tree2", rotation=4, nCharNodes=4, nCharEdges=4, 
##          optimizeLatRes=F, residScale=10)


