lsttheory
=========

An R package for LST-R theory models. 
